import 'package:flutter/material.dart';

class RecomData extends StatelessWidget{
  @override
  Widget build(BuildContext context){
    return Scaffold(
      appBar: AppBar(
        title: Text('Recommendation Log')
      ),
      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [Text('Recommendation Log'),
          OutlinedButton(onPressed: () {}, child:Text('View')),
          OutlinedButton(onPressed: () {
            Navigator.of(context).pop();
          },
          child:Text('Back to Home'),
          )
          ],
        ),
      ),
    );
  }
}