import 'package:flutter/material.dart';
import 'package:haveeat/screens/2UserData.dart';

class Login extends StatelessWidget {
  @override
  Widget build(BuildContext context){
    return Scaffold(appBar: AppBar(
      title:Text('LOGIN')
    ), 
    body: Center(child: Column(
      mainAxisAlignment:MainAxisAlignment.center,
        children: [TextField(
          decoration: InputDecoration(
            border:OutlineInputBorder(),
            labelText: 'ID',
          )
          ),
          TextField(
            obscureText: true,
            decoration: InputDecoration(
              border:OutlineInputBorder(),
              labelText:'Password',
            )
          ),        
        ElevatedButton(onPressed:() {
          Navigator.of(context).push(
            MaterialPageRoute(
              builder: (BuildContext context) => UserData(),
              ),
          );
        },
        child:Text('LOGIN'),)
        ],
        ),
      ),
    );
  }
}