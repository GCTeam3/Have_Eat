import 'package:flutter/material.dart';
import 'package:haveeat/screens/3Home.dart';

class UserData extends StatelessWidget{
  @override
  Widget build(BuildContext context){
    return Scaffold(
      appBar: AppBar(
        title: Text('Input User Data')
      ),
      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [TextField(
          decoration: InputDecoration(
            border:OutlineInputBorder(),
            labelText: 'Name',
          )
          ),
          TextField(
          decoration: InputDecoration(
            border:OutlineInputBorder(),
            labelText: 'Age',
          )
          ),
          TextField(
          decoration: InputDecoration(
            border:OutlineInputBorder(),
            labelText: 'Height',
          )
          ),
          TextField(
          decoration: InputDecoration(
            border:OutlineInputBorder(),
            labelText: 'Weight',
          )
          ),
          TextField(
          decoration: InputDecoration(
            border:OutlineInputBorder(),
            labelText: 'Exercise Hours Per a Week',
          )
          ),
          TextField(
          decoration: InputDecoration(
            border:OutlineInputBorder(),
            labelText: 'Like Food',
          )
          ),
          TextField(
          decoration: InputDecoration(
            border:OutlineInputBorder(),
            labelText: 'Hate Food',
          )
          ),
          OutlinedButton(onPressed: () {
            Navigator.of(context).push(
              MaterialPageRoute(
                builder: (BuildContext context) => Home()
                ),
            );
          }, child:Text('Apply'))
          ],
        ),
      ),
    );
  }
}