import 'package:flutter/material.dart';
import 'package:haveeat/screens/41recom.dart';

class Recom extends StatelessWidget{

  @override
  Widget build(BuildContext context){
    return Scaffold(
      appBar: AppBar(
        title: Text('Recommendation')
      ),
      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
          OutlinedButton(onPressed: () {
            Navigator.of(context).push(
              MaterialPageRoute(
                builder: (BuildContext context) => Recomm(),
              ),
            );
          }, child:Text('Recommendation')),
          Text('Recommendation Result'),
          OutlinedButton(onPressed: () {
            Navigator.of(context).pop();
          },
          child:Text('Back to Home'),
          )
          ],
        ),
      ),
    );
  }
}