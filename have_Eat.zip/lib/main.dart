import 'package:flutter/material.dart';
import 'package:haveeat/screens/1Login.dart';

void main() {
  runApp(MyApp());
}
class MyApp extends StatelessWidget{
  @override
  Widget build(BuildContext context){
    return MaterialApp(
      title: 'HaveEat Demo',
      theme: ThemeData(primarySwatch: Colors.blue,
      ),
      home: Login(),
    );
  }
}