import 'package:flutter/material.dart';

class Recomm extends StatelessWidget{
  var output_text = "==Recommendation Diet==" + '\n' + "곡류군 : 밤 600 g" + '\n' + 
      "어육류군 : 검정콩 100 g" + '\n' + "채소군 : 표고버섯 350 g" + '\n' + "지방군 : 참기름 20 g" + '\n' +
      "우유군 : 두유 400 g" + '\n' + "과일군 : 단감 100 g";
  
  @override
  Widget build(BuildContext context){
    return Scaffold(
      appBar: AppBar(
        title: Text('Recommendation')
      ),
      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
          OutlinedButton(onPressed: () {}, child:Text('Recommendation')),
          Text(output_text),
          OutlinedButton(onPressed: () {
            Navigator.of(context).pop();
          },
          child:Text('Back to Home'),
          )
          ],
        ),
      ),
    );
  }
}