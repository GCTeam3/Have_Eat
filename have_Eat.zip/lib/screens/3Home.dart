import 'package:flutter/material.dart';
import 'package:haveeat/screens/4Recom.dart';
import 'package:haveeat/screens/5InputDiet.dart';
import 'package:haveeat/screens/6RecomData.dart';

class Home extends StatelessWidget{
  @override
  Widget build(BuildContext context){
    return Scaffold(
      appBar: AppBar(
        title: Text('Home')
        ),
      body: Center(
        child: Row(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
          ElevatedButton(onPressed: () {
            Navigator.of(context).push(
              MaterialPageRoute(
                builder: (BuildContext context) => Recom(),
                ),
            );
          }, child:Text('Recommendation')),
          ElevatedButton(onPressed: () {
            Navigator.of(context).push(
              MaterialPageRoute(
                builder: (BuildContext context) => InputDiet(),
              ),
            );
          }, child:Text('Input Diet')),
          ElevatedButton(onPressed: () {
            Navigator.of(context).push(
              MaterialPageRoute(
                builder: (BuildContext context) => RecomData(),
            ),
            );
          }, child:Text('Diet Record'))
          ],
        ),
      ),
    );
  }
}