import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'dart:convert';
import 'dart:async';
import 'package:http/http.dart' as http;

enum DataKind{NONE, RESULT}

Future<String> fetchString(DataKind kind) async{
  if(kind==DataKind.NONE)
    return "";

  print(kind.toString());
  print(kind.toString().split('.')[1]);

  final details = ['', 'result'];
  final urlPath = 'https://www.pythonanywhere.com/user/yeeunKim/files/home/yeeunKim/' + details[kind.index];
  final response = await http.get(urlPath);

  if(response.statusCode==200)
    return response.body;
  throw Exception('데이터 수신 실패');
}

class RecomData extends StatefulWidget{
  DataKind mKind = DataKind.NONE;

  Widget makeChild(String str){
    switch(mKind){
      case DataKind.NONE:
        return Placeholder();
      case DataKind.RESULT:
        return Text(str, style:TextStyle(fontSize:12),);
      default:
        final items = json.decode(str);
        final textStyle = TextStyle(fontSize:12, fontWeight:FontWeight.normal);

        List<Container> widgets = [];
        for (var item in items){
          widgets.add(
            Container(
              child:Column(
                children:<Widget>[
                  Text(item['id'].toSTring(), style:textStyle),
                  Text(item['content'], style:textStyle, softWrap:true),
                ],
              ),
              padding:EdgeInsets.all(20.0),
            ),
          );
        }
        return Column(children:widgets);
    }
  }

  @override
  Widget build(BuildContext context){
    return Scaffold(
      appBar: AppBar(
        title: Text('Recommendation Log')
      ),
      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [Text('Recommendation Log'),
          OutlinedButton(onPressed: () {
            makeChild(DataKind.RESULT.toString());
          }, child:Text('View')),
          OutlinedButton(onPressed: () {
            Navigator.of(context).pop();
          },
          child:Text('Back to Home'),
          )
          ],
        ),
      ),
    );
  }

}
