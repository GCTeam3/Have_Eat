import 'package:flutter/material.dart';

class InputDiet extends StatelessWidget{
  @override
  Widget build(BuildContext context){
    return Scaffold(
      appBar: AppBar(
        title: Text('Input Diet')
      ),
      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
          OutlinedButton(onPressed: () {}, child:Text('Input')),
          TextField(
          decoration: InputDecoration(
            border:OutlineInputBorder(),
            labelText: 'Input Diet',
          )
          ),
          OutlinedButton(onPressed: () {
            Navigator.of(context).pop();
          },
          child:Text('Back to Home'),
          )
          ],
        ),
      ),
    );
  }
}